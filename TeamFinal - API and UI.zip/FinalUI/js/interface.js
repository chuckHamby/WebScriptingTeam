//Global Login
var username;
var password;

// ========== < < VALIDATION > > ========== \\
function validateEmptyProduct()
{
    var msg = "";
    var validPN = document.getElementById("PN").value.trim();
    var validName = document.getElementById("Name").value.trim();
    var validDesc = document.getElementById("Desc").value.trim();
    var validPrice = document.getElementById("Price").value.trim();
    var validBlkPrice = document.getElementById("BlkPrice").value.trim();
    var validBlkAmt = document.getElementById("BlkAmt").value.trim();
    var validQOH = document.getElementById("QOH").value.trim();

    if (validPN.length == 0 || validPN == "")
    {
        msg += "Empty Product Number\n";
    }
    if (validName.length == 0 || validName == "")
    {
        msg += "Empty Product Name\n";
    }
    if (validDesc.length == 0 || validDesc == "")
    {
        msg += "Empty Description\n";
    }
    if (validPrice.length == 0 || validPrice == "")
    {
        msg += "Empty Product Price\n";
    }
    if (validBlkPrice.length == 0 || validBlkPrice == "")
    {
        msg += "Empty Bulk Price\n";
    }
    if (validBlkAmt.length == 0 || validBlkAmt == "")
    {
        msg += "Empty Bulk Amount\n";
    }
    if (validQOH.length == 0 || validQOH == "")
    {
        msg += "Empty QOH\n";
    }
    if (msg == "")
    {
        return false;
    }
    else
    {
        alert(msg);
        return true;
    }
}

function validateEmptyAdmin()
{
    var msg = "";
    var validID = document.getElementById("adminID").value.trim();
    var validPassword = document.getElementById("password").value.trim();
    var validName = document.getElementById("adminName").value.trim();
    var validEmail = document.getElementById("email").value.trim();

    if (validID.length == 0 || validID == "")
    {
        msg += "Empty Admin ID\n";
    }
    if (validPassword.length == 0 || validPassword == "")
    {
        msg += "Empty Password\n";
    }
    if (validName.length == 0 || validName == "")
    {
        msg += "Empty Name\n";
    }
    if (validEmail.length == 0 || validEmail == "")
    {
        msg += "Empty Email\n";
    }
    if (msg == "")
    {
        return false;
    }
    else
    {
        alert(msg);
        return true;
    }
}

// ========== < < FUNCTIONALITY FUNCTIONS > > ========== \\
function login()                                                                                                        //done - good
{

    username = document.getElementById("usernameBox").value;
    password = document.getElementById("passwordBox").value;

    //Body to be sent to the API
    var body = new Object();

    //body['string'] - 'string' has to match with the backend
    body["username"] = username;
    body["password"] = password;

    //Creates json {"username":usernameBox(value),"password":passwordBox(value)}
    var json = JSON.stringify(body);

    //AJAX to call API, gives user in JSON format
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function()
    {
        if (this.readyState == 4 && this.status == 200)
        {
            //alert("Login Successful");
            clearContent();
            displayAdminButtons();

            var response = xhttp.responseText;
            var jsonItems = JSON.parse(response);
            document.getElementById("content").innerHTML = "<br/> <h2>Welcome: " + jsonItems.data.user.name + "</h2>";

            // =-=-=- HOW TO LOOP THROUGH A JSON ARRAY -=-=-=
            // var users = jsonItems.data.users;
            // users.forEach(function(u){
            //    console.log(u.username);
            // });

        }
        else if (this.readyState == 4 && this.status != 200)
        {
            alert("Invalid Credentials");
        }
    };

    //Only thing that will change is web address.
    xhttp.open("POST","http://localhost/admin",true);
    xhttp.send(json);
}

function logout()                                                                                                       //done - good
{
    clearContent();
    hideAdminButtons();
}

function addProduct()                                                                                                   //done - more validation?
{
    var isEmpty = validateEmptyProduct();

    if (isEmpty)
    {
        return false;
    }

    //Body to be sent to the API
    var body = new Object();

    //body['string'] - 'string' has to match with the backend
    body["adminID"] = username;
    body["productID"] = document.getElementById("PN").value;
    body["name"] = document.getElementById("Name").value;
    body["prodDesc"] = document.getElementById("Desc").value;
    body["unitPrice"] = document.getElementById("Price").value;
    body["bulkPrice"] = document.getElementById("BlkPrice").value;
    body["bulkMinAmt"] = document.getElementById("BlkAmt").value;
    body["QOH"] = document.getElementById("QOH").value;

    //Creates json {"username":usernameBox(value),"password":passwordBox(value)}
    var json = JSON.stringify(body);

    //AJAX to call API, gives user in JSON format
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function()
    {
        if (this.readyState == 4 && this.status == 200)
        {
            var response = xhttp.responseText;
            var jsonItems = JSON.parse(response);
            alert("Product Added " + jsonItems.data.user.name);

            document.getElementById("PN").value = "";
            document.getElementById("Name").value = "";
            document.getElementById("Desc").value = "";
            document.getElementById("Price").value = "";
            document.getElementById("BlkPrice").value = "";
            document.getElementById("BlkAmt").value = "";
            document.getElementById("QOH").value = "";

        }
        else if (this.readyState == 4 && this.status != 200)
        {
            alert("The Product was not added");
        }
    };

    //Only thing that will change is web address.
    xhttp.open("POST","http://localhost/new-product",true);
    xhttp.send(json);
}

function showProducts()                                                                                                 //done - good
{

    //Body to be sent to the API
    var body = new Object();

    //body['string'] - 'string' has to match with the backend
    body["adminID"] = username;

    //Creates json {"username":usernameBox(value),"password":passwordBox(value)}
    var json = JSON.stringify(body);

    //AJAX to call API, gives user in JSON format
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function()
    {
        if (this.readyState == 4 && this.status == 200)
        {
            //Displays the product header
            displayProducts();

            var content = document.getElementById("content");
            var productContent = createNode("DIV", [{"name":"id", "value":"Remove"}, {"name":"class", "value":"column sides table-header center-align"}]);
            content.appendChild(productContent);
            var remove = createNode("LABEL",[{"name":"id","value":"Remove"}]);
            remove.innerText = "Remove";
            productContent.appendChild(remove);

            var productContent = createNode("DIV", [{"name":"id", "value":"Edit"}, {"name":"class", "value":"column sides table-header center-align"}]);
            content.appendChild(productContent);
            var edit = createNode("LABEL",[{"name":"id","value":"Edit"}]);
            edit.innerText = "Edit";
            productContent.appendChild(edit);
            content.innerHTML += "<br/>";

            var response = xhttp.responseText;
            var jsonItems = JSON.parse(response);

            // Loops through each JSON record and display
             var users = jsonItems.data.user;
            var index = 0;
             users.forEach(function(user){
                 var maincontent = document.getElementById("content");

                 var content = createNode("DIV", [{"name":"id", "value":"row_" + index}, {"name":"class", "value":"row data"}]);
                 maincontent.appendChild(content);

                 var productContent = createNode("DIV", [{"name":"id", "value":"product_" + index}, {"name":"class", "value":"column sides center-align table-row"}]);
                 content.appendChild(productContent);

                 var productID = createNode("LABEL",[{"name":"class","value":""}]);
                 productID.innerText = user.productID;
                 productContent.appendChild(productID);

                 productContent = createNode("DIV", [{"name":"id", "value":"product_" + index}, {"name":"class", "value":"column sides center-align table-row"}]);
                 content.appendChild(productContent);
                 var name = createNode("LABEL",[{"name":"class","value":""}]);
                 name.innerText = user.name;
                 productContent.appendChild(name);

                 productContent = createNode("DIV", [{"name":"id", "value":"product_" + index}, {"name":"class", "value":"column sides center-align table-row"}]);
                 content.appendChild(productContent);
                 var prodDesc = createNode("LABEL",[{"name":"class","value":""}]);
                 prodDesc.innerText = user.prodDesc;
                 productContent.appendChild(prodDesc);

                 productContent = createNode("DIV", [{"name":"id", "value":"product_" + index}, {"name":"class", "value":"column sides center-align table-row"}]);
                 content.appendChild(productContent);
                 var unitPrice = createNode("LABEL",[{"name":"class","value":""}]);
                 unitPrice.innerText = user.unitPrice;
                 productContent.appendChild(unitPrice);

                 productContent = createNode("DIV", [{"name":"id", "value":"product_" + index}, {"name":"class", "value":"column sides center-align table-row"}]);
                 content.appendChild(productContent);
                 var bulkPrice = createNode("LABEL",[{"name":"class","value":""}]);
                 bulkPrice.innerText = user.bulkPrice;
                 productContent.appendChild(bulkPrice);

                 productContent = createNode("DIV", [{"name":"id", "value":"product_" + index}, {"name":"class", "value":"column sides center-align table-row"}]);
                 content.appendChild(productContent);
                 var bulkAmount = createNode("LABEL",[{"name":"class","value":""}]);
                 bulkAmount.innerText = user.bulkMinAmt;
                 productContent.appendChild(bulkAmount);

                 productContent = createNode("DIV", [{"name":"id", "value":"product_" + index}, {"name":"class", "value":"column sides center-align table-row"}]);
                 content.appendChild(productContent);
                 var stock = createNode("LABEL",[{"name":"class","value":""}]);
                 stock.innerText = user.QOH;
                 productContent.appendChild(stock);

                 // productContent = createNode("DIV", [{"name":"id", "value":"product_" + index}, {"name":"class", "value":"column sides center-align table-row"}]);
                 // content.appendChild(productContent);
                 // var dateAdded = createNode("LABEL",[{"name":"class","value":""}]);
                 // dateAdded.innerText = user.dateAdded;
                 // productContent.appendChild(dateAdded);
                 //
                 // productContent = createNode("DIV", [{"name":"id", "value":"product_" + index}, {"name":"class", "value":"column sides center-align table-row"}]);
                 // content.appendChild(productContent);
                 // var dateUpdated = createNode("LABEL",[{"name":"class","value":""}]);
                 // dateUpdated.innerText = user.dateUpdated;
                 // productContent.appendChild(dateUpdated);

                 //REMOVE BUTTON
                 productContent = createNode("DIV", [{"name":"id", "value":"product_" + index}, {"name":"class", "value":"column sides center-align"}]);
                 var removeButton = createNode("INPUT", [{"name":"type","value":"button"},
                     {"name":"id", "value":"remove_" + user.productID},
                     {"name":"name", "value":"remove_" + index},
                     {"name":"class", "value":"input"},
                     {"name":"value","value": "Remove"}]);

                 removeButton.addEventListener("click",removeItem(user.productID));
                 productContent.appendChild(removeButton);
                 content.appendChild(productContent);

                 //EDIT BUTTON
                 productContent = createNode("DIV", [{"name":"id", "value":"product_" + index}, {"name":"class", "value":"column sides center-align"}]);
                 var editButton = createNode("INPUT", [{"name":"type","value":"button"},
                     {"name":"id", "value":"edit_" + user.productID},
                     {"name":"name", "value":"edit_" + index},
                     {"name":"class", "value":"input"},
                     {"name":"value","value": "Edit Product"}]);

                 editButton.addEventListener("click",editProduct(user.productID,user.name,user.prodDesc,user.unitPrice,user.bulkPrice,user.bulkMinAmt,user.QOH));
                 productContent.appendChild(editButton);
                 content.appendChild(editButton);

                 index += 1;
             });

        }
        else if (this.readyState == 4 && this.status != 200)
        {
            //Stops user from going to products 'page'
            clearContent();
            document.getElementById("content").innerHTML = "<h2>NO PRODUCTS FOUND</h2>";

        }
    };

    //Only thing that will change is web address.
    xhttp.open("POST","http://localhost/products",true);
    xhttp.send(json);
}

function searchProducts()                                                                                               //done - good
{
    //Body to be sent to the API
    var body = new Object();

    //body['string'] - 'string' has to match with the backend
    body["adminID"] = username;
    var name = document.getElementById("searchName").value;
    var ProductID = document.getElementById("searchID").value;
    if (ProductID == "")
    {
        ProductID = "%";
    }
    body["name"] = "%" + name + "%";
    body["productID"] = ProductID;

    //Creates json {"username":usernameBox(value),"password":passwordBox(value)}
    var json = JSON.stringify(body);

    //AJAX to call API, gives user in JSON format
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function()
    {
        if (this.readyState == 4 && this.status == 200)
        {
            var content = document.getElementById("content");
            while (content.hasChildNodes() && content.childElementCount > 5)
            {
                content.removeChild(content.lastChild);
            }

            //Displays the product header
            content = document.getElementById("content");
            content.innerHTML += "<br/><br/><br/>";
            productsTableHeader();
            // var productContent = createNode("DIV", [{"name":"id", "value":"DateAdded"}, {"name":"class", "value":"column sides table-header center-align"}]);
            // content.appendChild(productContent);
            // var DateAdded = createNode("LABEL",[{"name":"id","value":"DateAdded"}]);
            // DateAdded.innerText = "Date Added";
            // productContent.appendChild(DateAdded);
            //
            // productContent = createNode("DIV", [{"name":"id", "value":"DateUpdated"}, {"name":"class", "value":"column sides table-header center-align"}]);
            // content.appendChild(productContent);
            // var DateUpdated = createNode("LABEL",[{"name":"id","value":"DateUpdated"}]);
            // DateUpdated.innerText = "Date Updated";
            // productContent.appendChild(DateUpdated);

            var content = document.getElementById("content");
            var productContent = createNode("DIV", [{"name":"id", "value":"Remove"}, {"name":"class", "value":"column sides table-header center-align"}]);
            content.appendChild(productContent);
            var remove = createNode("LABEL",[{"name":"id","value":"Remove"}]);
            remove.innerText = "Remove";
            productContent.appendChild(remove);

            var productContent = createNode("DIV", [{"name":"id", "value":"Edit"}, {"name":"class", "value":"column sides table-header center-align"}]);
            content.appendChild(productContent);
            var edit = createNode("LABEL",[{"name":"id","value":"Edit"}]);
            edit.innerText = "Edit";
            productContent.appendChild(edit);
            content.innerHTML += "<br/>";

            var response = xhttp.responseText;
            var jsonItems = JSON.parse(response);

            // Loops through each JSON record and display
            var users = jsonItems.data.user;
            users.forEach(function(user){
                var index = 0;

                var productContent = createNode("DIV", [{"name":"id", "value":"product_" + index}, {"name":"class", "value":"column sides center-align table-row"}]);
                content.appendChild(productContent);

                var productID = createNode("LABEL",[{"name":"class","value":""}]);
                productID.innerText = user.productID;
                productContent.appendChild(productID);

                productContent = createNode("DIV", [{"name":"id", "value":"product_" + index}, {"name":"class", "value":"column sides center-align table-row"}]);
                content.appendChild(productContent);
                var name = createNode("LABEL",[{"name":"class","value":""}]);
                name.innerText = user.name;
                productContent.appendChild(name);

                productContent = createNode("DIV", [{"name":"id", "value":"product_" + index}, {"name":"class", "value":"column sides center-align table-row"}]);
                content.appendChild(productContent);
                var prodDesc = createNode("LABEL",[{"name":"class","value":""}]);
                prodDesc.innerText = user.prodDesc;
                productContent.appendChild(prodDesc);

                productContent = createNode("DIV", [{"name":"id", "value":"product_" + index}, {"name":"class", "value":"column sides center-align table-row"}]);
                content.appendChild(productContent);
                var unitPrice = createNode("LABEL",[{"name":"class","value":""}]);
                unitPrice.innerText = user.unitPrice;
                productContent.appendChild(unitPrice);

                productContent = createNode("DIV", [{"name":"id", "value":"product_" + index}, {"name":"class", "value":"column sides center-align table-row"}]);
                content.appendChild(productContent);
                var bulkPrice = createNode("LABEL",[{"name":"class","value":""}]);
                bulkPrice.innerText = user.bulkPrice;
                productContent.appendChild(bulkPrice);

                productContent = createNode("DIV", [{"name":"id", "value":"product_" + index}, {"name":"class", "value":"column sides center-align table-row"}]);
                content.appendChild(productContent);
                var bulkAmount = createNode("LABEL",[{"name":"class","value":""}]);
                bulkAmount.innerText = user.bulkMinAmt;
                productContent.appendChild(bulkAmount);

                productContent = createNode("DIV", [{"name":"id", "value":"product_" + index}, {"name":"class", "value":"column sides center-align table-row"}]);
                content.appendChild(productContent);
                var stock = createNode("LABEL",[{"name":"class","value":""}]);
                stock.innerText = user.QOH;
                productContent.appendChild(stock);

                // productContent = createNode("DIV", [{"name":"id", "value":"product_" + index}, {"name":"class", "value":"column sides center-align table-row"}]);
                // content.appendChild(productContent);
                // var dateAdded = createNode("LABEL",[{"name":"class","value":""}]);
                // dateAdded.innerText = user.dateAdded;
                // productContent.appendChild(dateAdded);
                //
                // productContent = createNode("DIV", [{"name":"id", "value":"product_" + index}, {"name":"class", "value":"column sides center-align table-row"}]);
                // content.appendChild(productContent);
                // var dateUpdated = createNode("LABEL",[{"name":"class","value":""}]);
                // dateUpdated.innerText = user.dateUpdated;
                // productContent.appendChild(dateUpdated);

                //REMOVE BUTTON
                productContent = createNode("DIV", [{"name":"id", "value":"product_" + index}, {"name":"class", "value":"column sides center-align"}]);
                var removeButton = createNode("INPUT", [{"name":"type","value":"button"},
                    {"name":"id", "value":"remove_" + user.productID},
                    {"name":"name", "value":"remove_" + index},
                    {"name":"class", "value":"input"},
                    {"name":"value","value": "Remove"}]);

                removeButton.addEventListener("click",removeItemSearch(user.productID));
                productContent.appendChild(removeButton);
                content.appendChild(productContent);

                //EDIT BUTTON
                productContent = createNode("DIV", [{"name":"id", "value":"product_" + index}, {"name":"class", "value":"column sides center-align"}]);
                var editButton = createNode("INPUT", [{"name":"type","value":"button"},
                    {"name":"id", "value":"edit_" + user.productID},
                    {"name":"name", "value":"edit_" + index},
                    {"name":"class", "value":"input"},
                    {"name":"value","value": "Edit Product"}]);

                editButton.addEventListener("click",editProduct(user.productID,user.name,user.prodDesc,user.unitPrice,user.bulkPrice,user.bulkMinAmt,user.QOH));
                productContent.appendChild(editButton);
                content.appendChild(editButton);

                index += 1;
            });
        }
        else if (this.readyState == 4 && this.status != 200)
        {
            //Clear Rows
            var content = document.getElementById("content");
            while (content.hasChildNodes() && content.childElementCount > 5)
            {
                content.removeChild(content.lastChild);
            }

            //Stops user from going to products 'page'
            content.innerHTML += "<h1>NO PRODUCTS FOUND</h1>";
        }

        //ReListen Search Button
        var searchButton = document.getElementById("search");
        searchButton.addEventListener("click",searchProducts);
    };

    //Only thing that will change is web address.
    xhttp.open("POST","http://localhost/search",true);
    xhttp.send(json);
}

function addAdmin()                                                                                                     //done - more validation?
{
    var isEmpty = validateEmptyAdmin();

    if (isEmpty)
    {
        return false;
    }

    //Body to be sent to the API
    var body = new Object();

    //body['string'] - 'string' has to match with the backend
    body["adminID"] = document.getElementById("adminID").value;
    body["password"] = document.getElementById("password").value;
    body["name"] = document.getElementById("adminName").value;
    body["email"] = document.getElementById("email").value;

    //Creates json {"username":usernameBox(value),"password":passwordBox(value)}
    var json = JSON.stringify(body);

    //AJAX to call API, gives user in JSON format
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function()
    {
        if (this.readyState == 4 && this.status == 200)
        {
            var response = xhttp.responseText;
            var jsonItems = JSON.parse(response);
            alert("Admin Added " + jsonItems.data.user.name);

            document.getElementById("adminID").value = "";
            document.getElementById("password").value = "";
            document.getElementById("adminName").value = "";
            document.getElementById("email").value = "";
        }
        else if (this.readyState == 4 && this.status != 200)
        {
            alert("Admin was not added");
        }
    };

    //Only thing that will change is web address.
    xhttp.open("POST","http://localhost/new-admin",true);
    xhttp.send(json);
}

function showAdmin()                                                                                                    //done - good
{

    //Body to be sent to the API
    var body = new Object();

    //body['string'] - 'string' has to match with the backend
    body["adminID"] = username;

    //Creates json {"username":usernameBox(value),"password":passwordBox(value)}
    var json = JSON.stringify(body);

    //AJAX to call API, gives user in JSON format
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function()
    {
        if (this.readyState == 4 && this.status == 200)
        {
            //Displays the product header
            displayAdmin();

            var response = xhttp.responseText;
            var jsonItems = JSON.parse(response);

            // Loops through each JSON record and display
            var users = jsonItems.data.user;
            var index = 0;
            users.forEach(function(user){
                var maincontent = document.getElementById("content");

                var content = createNode("DIV", [{"name":"id", "value":"row_" + index}, {"name":"class", "value":"row data"}]);
                maincontent.appendChild(content);

                var adminContent = createNode("DIV", [{"name":"id", "value":"admin_" + index}, {"name":"class", "value":"column sides center-align table-row"}]);
                content.appendChild(adminContent);
                var adminID = createNode("LABEL",[{"name":"class","value":""}]);
                adminID.innerText = user.username;
                adminContent.appendChild(adminID);

                adminContent = createNode("DIV", [{"name":"id", "value":"admin_" + index}, {"name":"class", "value":"column sides center-align table-row"}]);
                content.appendChild(adminContent);
                var Password = createNode("LABEL",[{"name":"class","value":""}]);
                Password.innerText = user.password;
                adminContent.appendChild(Password);

                adminContent = createNode("DIV", [{"name":"id", "value":"admin_" + index}, {"name":"class", "value":"column sides center-align table-row"}]);
                content.appendChild(adminContent);
                var Name = createNode("LABEL",[{"name":"class","value":""}]);
                Name.innerText = user.name;
                adminContent.appendChild(Name);

                adminContent = createNode("DIV", [{"name":"id", "value":"admin_" + index}, {"name":"class", "value":"column sides center-align table-row"}]);
                content.appendChild(adminContent);
                var active = createNode("LABEL",[{"name":"class","value":""}]);
                active.innerText = user.activeIndicator;
                adminContent.appendChild(active);

                // adminContent = createNode("DIV", [{"name":"id", "value":"admin_" + index}, {"name":"class", "value":"column sides center-align table-row"}]);
                // content.appendChild(adminContent);
                // var dateAdded = createNode("LABEL",[{"name":"class","value":""}]);
                // dateAdded.innerText = user.createdDate;
                // adminContent.appendChild(dateAdded);
                //
                // adminContent = createNode("DIV", [{"name":"id", "value":"admin_" + index}, {"name":"class", "value":"column sides center-align table-row"}]);
                // content.appendChild(adminContent);
                // var dateUpdated = createNode("LABEL",[{"name":"class","value":""}]);
                // dateUpdated.innerText = user.lastUpdated;
                // adminContent.appendChild(dateUpdated);

                adminContent = createNode("DIV", [{"name":"id", "value":"admin_" + index}, {"name":"class", "value":"column sides center-align table-row"}]);
                content.appendChild(adminContent);
                var Email = createNode("LABEL",[{"name":"class","value":""}]);
                Email.innerText = user.email;
                adminContent.appendChild(Email);

                //REMOVE BUTTON
                adminContent = createNode("DIV", [{"name":"id", "value":"admin_" + index}, {"name":"class", "value":"column sides center-align"}]);
                var removeButton = createNode("INPUT", [{"name":"type","value":"button"},
                    {"name":"id", "value":"remove_" + user.username},
                    {"name":"name", "value":"remove_" + index},
                    {"name":"class", "value":"input"},
                    {"name":"value","value": "Remove"}]);

                removeButton.addEventListener("click",removeAdmin(user.username));
                adminContent.appendChild(removeButton);
                content.appendChild(adminContent);

                //EDIT BUTTON
                adminContent = createNode("DIV", [{"name":"id", "value":"admin_" + index}, {"name":"class", "value":"column sides center-align"}]);
                var editButton = createNode("INPUT", [{"name":"type","value":"button"},
                    {"name":"id", "value":"edit_" + user.username},
                    {"name":"name", "value":"edit_" + index},
                    {"name":"class", "value":"input"},
                    {"name":"value","value": "Edit Admin"}]);

                editButton.addEventListener("click",editAdmin(user.username,user.password,user.name,user.email));
                adminContent.appendChild(editButton);
                content.appendChild(editButton);

                index += 1;
            });

        }
        else if (this.readyState == 4 && this.status != 200)
        {
            //Stops user from going to products 'page'
            clearContent();
            document.getElementById("content").innerHTML = "<h2>NO ADMINS FOUND</h2>";

        }
    };

    //Only thing that will change is web address.
    xhttp.open("POST","http://localhost/admins",true);
    xhttp.send(json);
}

function removeAdmin(index)                                                                                             //done - good
{

    return function()
    {
        // var deleteItem = confirm("Are you sure you want to deactivate account: " + index);
        // if (!deleteItem)
        // {
        //     return false;
        // }
        //Body to be sent to the API
        var body = new Object();

        //body['string'] - 'string' has to match with the backend
        body["adminID"] = index;

        //Creates json {"username":usernameBox(value),"password":passwordBox(value)}
        var json = JSON.stringify(body);

        //AJAX to call API, gives user in JSON format
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function()
        {
            if (this.readyState == 4 && this.status == 200)
            {

            }
            else if (this.readyState == 4 && this.status != 200)
            {

            }
        };

        //Only thing that will change is web address.
        xhttp.open("POST","http://localhost/delete-admin",true);
        xhttp.send(json);

        showAdmin();
    }


}

function editAdmin(index,password,name,email)                                                                           //done - more validation?
{

    return function()
    {
        //alert("Edit Admin " + index);
        displayEditAdminForm(index,password,name,email);
    }
}

function updateAdmin()
{
    //Body to be sent to the API
    var body = new Object();

    //body['string'] - 'string' has to match with the backend
    body["adminID"] = document.getElementById("adminID").value;
    body["password"] = document.getElementById("password").value;
    body["name"] = document.getElementById("adminName").value;
    body["email"] = document.getElementById("email").value;

    //Creates json {"username":usernameBox(value),"password":passwordBox(value)}
    var json = JSON.stringify(body);

    //AJAX to call API, gives user in JSON format
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function()
    {
        if (this.readyState == 4 && this.status == 200)
        {
            showAdmin();
        }
        else if (this.readyState == 4 && this.status != 200)
        {
            alert("The Product was not updated");
        }
    };

    //Only thing that will change is web address.
    xhttp.open("POST","http://localhost/edit-admin",true);
    xhttp.send(json);

}

function removeItem(index)                                                                                              //done - good
{

    return function()
    {
        var deleteItem = confirm("Are you sure you want to delete item #" + index);
        if (!deleteItem)
        {
            return false;
        }
        //Body to be sent to the API
        var body = new Object();

        //body['string'] - 'string' has to match with the backend
        body["adminID"] = username;
        body["productID"] = index;

        //Creates json {"username":usernameBox(value),"password":passwordBox(value)}
        var json = JSON.stringify(body);

        //AJAX to call API, gives user in JSON format
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function()
        {
            if (this.readyState == 4 && this.status == 200)
            {

            }
            else if (this.readyState == 4 && this.status != 200)
            {

            }
        };

        //Only thing that will change is web address.
        xhttp.open("POST","http://localhost/delete-product",true);
        xhttp.send(json);

        showProducts();
    }


}

function removeItemSearch(index)                                                                                        //done - good
{

    return function()
    {
        var deleteItem = confirm("Are you sure you want to delete item #" + index);
        if (!deleteItem)
        {
            return false;
        }
        //Body to be sent to the API
        var body = new Object();

        //body['string'] - 'string' has to match with the backend
        body["adminID"] = username;
        body["productID"] = index;

        //Creates json {"username":usernameBox(value),"password":passwordBox(value)}
        var json = JSON.stringify(body);

        //AJAX to call API, gives user in JSON format
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function()
        {
            if (this.readyState == 4 && this.status == 200)
            {

            }
            else if (this.readyState == 4 && this.status != 200)
            {

            }
        };

        //Only thing that will change is web address.
        xhttp.open("POST","http://localhost/delete-product",true);
        xhttp.send(json);

        searchProducts();
    }


}

function editProduct(index,name,prodDesc,unitPrice,bulkPrice,bulkMinAmt,QOH)                                            //done - good
{

    return function()
    {
        //alert("Edit Product #" + index);
        displayEditProductForm(index,name,prodDesc,unitPrice,bulkPrice,bulkMinAmt,QOH);
    }
}

function updateProduct()                                                                                                //done - more validation?
{
    var isEmpty = validateEmptyProduct();

    if (isEmpty)
    {
        return false;
    }
    //Body to be sent to the API
    var body = new Object();

    //body['string'] - 'string' has to match with the backend
    body["adminID"] = username;
    body["productID"] = document.getElementById("PN").value;
    body["name"] = document.getElementById("Name").value;
    body["prodDesc"] = document.getElementById("Desc").value;
    body["unitPrice"] = document.getElementById("Price").value;
    body["bulkPrice"] = document.getElementById("BlkPrice").value;
    body["bulkMinAmt"] = document.getElementById("BlkAmt").value;
    body["QOH"] = document.getElementById("QOH").value;

    //Creates json {"username":usernameBox(value),"password":passwordBox(value)}
    var json = JSON.stringify(body);

    //AJAX to call API, gives user in JSON format
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function()
    {
        if (this.readyState == 4 && this.status == 200)
        {
            showProducts();
        }
        else if (this.readyState == 4 && this.status != 200)
        {
            alert("The Product was not updated");
        }
    };

    //Only thing that will change is web address.
    xhttp.open("POST","http://localhost/edit-product",true);
    xhttp.send(json);
}

// ========== < < DISPLAY/HIDE PAGES > > ========== \\

//Display form to add an Admin                                                                                          //done - good
function displayAddAdminForm()
{
    clearContent();
    var content = document.getElementById("content");
    content.innerHTML = "<h2>Add Admin</h2><br/>";

    var adminID = createNode("INPUT", [{"name": "type", "value": "text"},
        {"name": "id", "value": "adminID"},
        {"name": "placeholder", "value": "Admin Username (ID)"}]);

    content.appendChild(adminID);

    content.innerHTML += "&nbsp;";

    var password = createNode("INPUT", [{"name": "type", "value": "text"},
        {"name": "id", "value": "password"},
        {"name": "placeholder", "value": "Password"}]);

    content.appendChild(password);

    content.innerHTML += "<br/>";

    var name = createNode("INPUT", [{"name": "type", "value": "text"},
        {"name": "id", "value": "adminName"},
        {"name": "placeholder", "value": "Name"}]);

    content.appendChild(name);

    content.innerHTML += "&nbsp;";

    var email = createNode("INPUT", [{"name": "type", "value": "text"},
        {"name": "id", "value": "email"},
        {"name": "placeholder", "value": "Email (example@email.com)"}]);

    content.appendChild(email);

    content.innerHTML += "<br/>";
    content.innerHTML += "<br/>";

    var addAdminButton = createNode("BUTTON", [{"name": "id", "value": "addAdmin"},
        {"name": "value", "value": "Add Admin"}]);

    addAdminButton.innerText = "Add Admin";
    content.appendChild(addAdminButton);

    addAdminButton.addEventListener("click", addAdmin);
}

function displayEditAdminForm(index,password,name,email)
{
    clearContent();
    var content = document.getElementById("content");
    content.innerHTML = "<h2>Edit Admin</h2><br/>";

    var adminID = createNode("INPUT", [{"name": "type", "value": "text"},
        {"name": "id", "value": "adminID"},
        {"name": "placeholder", "value": "Admin Username (ID)"},
        {"name": "value", "value":index},
        {"name":"readonly","value":""}]);

    content.appendChild(adminID);

    content.innerHTML += "&nbsp;";

    var password = createNode("INPUT", [{"name": "type", "value": "text"},
        {"name": "id", "value": "password"},
        {"name": "placeholder", "value": "Password"},
        {"name": "value", "value":password}]);

    content.appendChild(password);

    content.innerHTML += "<br/>";

    var name = createNode("INPUT", [{"name": "type", "value": "text"},
        {"name": "id", "value": "adminName"},
        {"name": "placeholder", "value": "Name"},
        {"name": "value", "value":name}]);

    content.appendChild(name);

    content.innerHTML += "&nbsp;";

    var email = createNode("INPUT", [{"name": "type", "value": "text"},
        {"name": "id", "value": "email"},
        {"name": "placeholder", "value": "Email (example@email.com)"},
        {"name": "value", "value":email}]);

    content.appendChild(email);

    content.innerHTML += "<br/>";
    content.innerHTML += "<br/>";

    var addAdminButton = createNode("BUTTON", [{"name": "id", "value": "editAdmin"},
        {"name": "value", "value": "editAdmin"}]);

    addAdminButton.innerText = "Update Admin";
    content.appendChild(addAdminButton);

    addAdminButton.addEventListener("click", updateAdmin);
}

//Display form to search <admin>'s products                                                                             //done - good
function displaySearchProductForm()
{
    clearContent();
    var searchContent = document.getElementById("content");

    searchContent.innerHTML = "<h2>Search</h2><br>";

    var searchName = createNode("INPUT", [{"name":"type", "value":"text"},
        {"name":"id","value":"searchName"},
        {"name":"placeholder","value":"Search Product Name"}]);
    searchContent.appendChild(searchName);

    searchContent.innerHTML += "&nbsp;";

    var searchID = createNode("INPUT", [{"name":"type", "value":"text"},
        {"name":"id","value":"searchID"},
        {"name":"placeholder","value":"Search Product ID"}]);
    searchContent.appendChild(searchID);

    searchContent.innerHTML += "&nbsp;";

    var searchButton = createNode("BUTTON", [{"name":"id","value":"search"},
        {"name":"value","value":"Search"}]);
    searchContent.appendChild(searchButton);
    searchButton.innerText = "Search";

    searchButton.addEventListener("click",searchProducts);

}

//Display form to add products                                                                                          //done - good
function displayAddProductForm()
{
    clearContent();
    var content = document.getElementById("content");
    content.innerHTML = "<h2>Add Product</h2><br>";
    productsTableHeader();

    content.innerHTML += "<br/>";

    var PN = createNode("INPUT", [{"name":"type", "value":"text"},
                                            {"name":"id","value":"PN"},
                                            {"name":"placeholder","value":"PN"},
                                            {"name":"size","value":11}]);

    content.appendChild(PN);

    var Name = createNode("INPUT", [{"name":"type", "value":"text"},
                                            {"name":"id","value":"Name"},
                                            {"name":"placeholder","value":"Name"},
                                            {"name":"size","value":15}]);

    content.appendChild(Name);

    var Desc = createNode("INPUT", [{"name":"type", "value":"text"},
                                            {"name":"id","value":"Desc"},
                                            {"name":"placeholder","value":"Description"},
                                            {"name":"size","value":20}]);

    content.appendChild(Desc);

    var Price = createNode("INPUT", [{"name":"type", "value":"text"},
                                            {"name":"id","value":"Price"},
                                            {"name":"placeholder","value":"Price"},
                                            {"name":"size","value":15}]);

    content.appendChild(Price);

    var BlkPrice = createNode("INPUT", [{"name":"type", "value":"text"},
                                            {"name":"id","value":"BlkPrice"},
                                            {"name":"placeholder","value":"Bulk Price"},
                                            {"name":"size","value":11}]);

    content.appendChild(BlkPrice);

    var BlkAmt = createNode("INPUT", [{"name":"type", "value":"text"},
                                            {"name":"id","value":"BlkAmt"},
                                            {"name":"placeholder","value":"Bulk Amount"},
                                            {"name":"size","value":11}]);

    content.appendChild(BlkAmt);

    var QOH = createNode("INPUT", [{"name":"type", "value":"text"},
                                            {"name":"id","value":"QOH"},
                                            {"name":"placeholder","value":"Stock (QOH)"},
                                            {"name":"size","value":11}]);

    content.appendChild(QOH);

    content.innerHTML += "<br/>";
    content.innerHTML += "<br/>";

    var addProductButton = createNode("BUTTON", [{"name":"id","value":"addProduct"},
                                            {"name":"value","value":"Add Product"}]);

    addProductButton.innerText = "Add Product";
    content.appendChild(addProductButton);

    addProductButton.addEventListener("click",addProduct);
}

//Display form to add products                                                                                          //done - good
function displayEditProductForm(prodNumber,name,desc,price,blkprice,blkminamt,qoh)
{
    clearContent();
    var content = document.getElementById("content");
    content.innerHTML = "<h2>Edit Product #"+ prodNumber +" - "+ name +"</h2><br>";
    productsTableHeader();

    content.innerHTML += "<br/>";

    var PN = createNode("INPUT", [{"name":"type", "value":"text"},
        {"name":"id","value":"PN"},
        {"name":"placeholder","value":"PN"},
        {"name":"size","value":11},
        {"name":"value","value":prodNumber},
        {"name":"readonly","value":""}]);

    content.appendChild(PN);

    var Name = createNode("INPUT", [{"name":"type", "value":"text"},
        {"name":"id","value":"Name"},
        {"name":"value","value":name},
        {"name":"size","value":15}]);

    content.appendChild(Name);

    var Desc = createNode("INPUT", [{"name":"type", "value":"text"},
        {"name":"id","value":"Desc"},
        {"name":"value","value":desc},
        {"name":"size","value":20}]);

    content.appendChild(Desc);

    var Price = createNode("INPUT", [{"name":"type", "value":"text"},
        {"name":"id","value":"Price"},
        {"name":"value","value":price},
        {"name":"size","value":15}]);

    content.appendChild(Price);

    var BlkPrice = createNode("INPUT", [{"name":"type", "value":"text"},
        {"name":"id","value":"BlkPrice"},
        {"name":"value","value":blkprice},
        {"name":"size","value":11}]);

    content.appendChild(BlkPrice);

    var BlkAmt = createNode("INPUT", [{"name":"type", "value":"text"},
        {"name":"id","value":"BlkAmt"},
        {"name":"value","value":blkminamt},
        {"name":"size","value":11}]);

    content.appendChild(BlkAmt);

    var QOH = createNode("INPUT", [{"name":"type", "value":"text"},
        {"name":"id","value":"QOH"},
        {"name":"value","value":qoh},
        {"name":"size","value":11}]);

    content.appendChild(QOH);

    content.innerHTML += "<br/>";
    content.innerHTML += "<br/>";

    var editProductButton = createNode("BUTTON", [{"name":"id","value":"addProduct"},
        {"name":"value","value":"Update Product"}]);

    editProductButton.innerText = "Update Product";
    content.appendChild(editProductButton);

    editProductButton.addEventListener("click",updateProduct);
}

//Display the Login Menu                                                                                                //done - good
function displayLogin()
{
    clearContent();
    var loginContent = document.getElementById("content");

    loginContent.innerHTML = "<h2>Login</h2><br>";

    var usernameBox = createNode("INPUT", [{"name":"type", "value":"text"},
                                            {"name":"id","value":"usernameBox"},
                                            {"name":"placeholder","value":"Enter Username"}]);
    loginContent.appendChild(usernameBox);

    loginContent.innerHTML += "<br/>";

    var passwordBox = createNode("INPUT", [{"name":"type", "value":"password"},
                                            {"name":"id","value":"passwordBox"},
                                            {"name":"placeholder","value":"Enter Password"}]);
    loginContent.appendChild(passwordBox);

    loginContent.innerHTML += "<br/>";

    var loginButton = createNode("BUTTON", [{"name":"id","value":"login"},
                                            {"name":"value","value":"Login"}]);
    loginContent.appendChild(loginButton);
    loginButton.innerText = "Login";

    loginButton.addEventListener("click",login);
}

//Displaying Admin Menu                                                                                                 //done - good
function displayAdminButtons()
{
    var logoutButton = document.getElementById("logout");
    var loginButton = document.getElementById("login");
    var nav = document.getElementById("nav");

    logoutButton.style.display = "inline-block";
    loginButton.style.display = "none";

    nav.style.visibility = "visible";
}

//Hiding Admin Menu                                                                                                     //done - good
function hideAdminButtons()
{
    var logoutButton = document.getElementById("logout");
    var loginButton = document.getElementById("login");
    var nav = document.getElementById("nav");

    logoutButton.style.display = "none";
    loginButton.style.display = "inline-block";

    nav.style.visibility = "hidden";
}

//Clear Content DIV                                                                                                     //done - good
function clearContent()
{
    document.getElementById("content").innerHTML = "";
}

//Default product table header                                                                                          //done - good
function productsTableHeader()
{
    var content = document.getElementById("content");

    var productContent = createNode("DIV", [{"name":"id", "value":"PNContent"}, {"name":"class", "value":"column sides table-header center-align"}]);
    content.appendChild(productContent);
    var PNLabel = createNode("LABEL",[{"name":"id","value":"PNLabel"}]);
    PNLabel.innerText = "Product Number";
    productContent.appendChild(PNLabel);

    productContent = createNode("DIV", [{"name":"id", "value":"NameContent"}, {"name":"class", "value":"column sides table-header center-align"}]);
    content.appendChild(productContent);
    var NameLabel = createNode("LABEL",[{"name":"id","value":"NameLabel"}]);
    NameLabel.innerText = "Name";
    productContent.appendChild(NameLabel);

    productContent = createNode("DIV", [{"name":"id", "value":"DescContent"}, {"name":"class", "value":"column sides table-header center-align"}]);
    content.appendChild(productContent);
    var DescLabel = createNode("LABEL",[{"name":"id","value":"DescLabel"}]);
    DescLabel.innerText = "Description";
    productContent.appendChild(DescLabel);

    productContent = createNode("DIV", [{"name":"id", "value":"PriceContent"}, {"name":"class", "value":"column sides table-header center-align"}]);
    content.appendChild(productContent);
    var PriceLabel = createNode("LABEL",[{"name":"id","value":"PriceLabel"}]);
    PriceLabel.innerText = "Price";
    productContent.appendChild(PriceLabel);

    productContent = createNode("DIV", [{"name":"id", "value":"BlkPriceContent"}, {"name":"class", "value":"column sides table-header center-align"}]);
    content.appendChild(productContent);
    var BlkPriceLabel = createNode("LABEL",[{"name":"id","value":"BlkPriceLabel"}]);
    BlkPriceLabel.innerText = "Bulk Price";
    productContent.appendChild(BlkPriceLabel);

    productContent = createNode("DIV", [{"name":"id", "value":"BlkAmtContent"}, {"name":"class", "value":"column sides table-header center-align"}]);
    content.appendChild(productContent);
    var BlkAmtLabel = createNode("LABEL",[{"name":"id","value":"BlkAmtLabel"}]);
    BlkAmtLabel.innerText = "Bulk Amount";
    productContent.appendChild(BlkAmtLabel);

    productContent = createNode("DIV", [{"name":"id", "value":"QOHContent"}, {"name":"class", "value":"column sides table-header center-align"}]);
    content.appendChild(productContent);
    var QOHLabel = createNode("LABEL",[{"name":"id","value":"QOHLabel"}]);
    QOHLabel.innerText = "Stock (QOH)";
    productContent.appendChild(QOHLabel);
}

//Products header - includes dated added/updated                                                                        //done - good
function displayProducts()
{
    clearContent();
    var content = document.getElementById("content");
    content.innerHTML = "<h2>My Products</h2><br>";
    productsTableHeader();

    // var productContent = createNode("DIV", [{"name":"id", "value":"DateAdded"}, {"name":"class", "value":"column sides table-header center-align"}]);
    // content.appendChild(productContent);
    // var DateAdded = createNode("LABEL",[{"name":"id","value":"DateAdded"}]);
    // DateAdded.innerText = "Date Added";
    // productContent.appendChild(DateAdded);
    //
    // productContent = createNode("DIV", [{"name":"id", "value":"DateUpdated"}, {"name":"class", "value":"column sides table-header center-align"}]);
    // content.appendChild(productContent);
    // var DateUpdated = createNode("LABEL",[{"name":"id","value":"DateUpdated"}]);
    // DateUpdated.innerText = "Date Updated";
    // productContent.appendChild(DateUpdated);

}

//Admins header
function displayAdmin()
{
    clearContent();
    var content = document.getElementById("content");
    content.innerHTML = "<h2>Admin List</h2><br>";

    var adminContent = createNode("DIV", [{"name":"id", "value":"adminIDContent"}, {"name":"class", "value":"column sides table-header center-align"}]);
    content.appendChild(adminContent);
    var adminIDLabel = createNode("LABEL",[{"name":"id","value":"adminIDLabel"}]);
    adminIDLabel.innerText = "AdminID";
    adminContent.appendChild(adminIDLabel);

    adminContent = createNode("DIV", [{"name":"id", "value":"passwordContent"}, {"name":"class", "value":"column sides table-header center-align"}]);
    content.appendChild(adminContent);
    var passwordLabel = createNode("LABEL",[{"name":"id","value":"passwordLabel"}]);
    passwordLabel.innerText = "Password";
    adminContent.appendChild(passwordLabel);

    productContent = createNode("DIV", [{"name":"id", "value":"nameContent"}, {"name":"class", "value":"column sides table-header center-align"}]);
    content.appendChild(productContent);
    var nameLabel = createNode("LABEL",[{"name":"id","value":"nameLabel"}]);
    nameLabel.innerText = "Name";
    productContent.appendChild(nameLabel);

    productContent = createNode("DIV", [{"name":"id", "value":"activeContent"}, {"name":"class", "value":"column sides table-header center-align"}]);
    content.appendChild(productContent);
    var activeLabel = createNode("LABEL",[{"name":"id","value":"activeLabel"}]);
    activeLabel.innerText = "Active";
    productContent.appendChild(activeLabel);

    // productContent = createNode("DIV", [{"name":"id", "value":"createdContent"}, {"name":"class", "value":"column sides table-header center-align"}]);
    // content.appendChild(productContent);
    // var createdLabel = createNode("LABEL",[{"name":"id","value":"createdLabel"}]);
    // createdLabel.innerText = "Date Created";
    // productContent.appendChild(createdLabel);
    //
    // productContent = createNode("DIV", [{"name":"id", "value":"updatedContent"}, {"name":"class", "value":"column sides table-header center-align"}]);
    // content.appendChild(productContent);
    // var updatedLabel = createNode("LABEL",[{"name":"id","value":"updatedLabel"}]);
    // updatedLabel.innerText = "Date Updated";
    // productContent.appendChild(updatedLabel);

    productContent = createNode("DIV", [{"name":"id", "value":"emailContent"}, {"name":"class", "value":"column sides table-header center-align"}]);
    content.appendChild(productContent);
    var emailLabel = createNode("LABEL",[{"name":"id","value":"emailLabel"}]);
    emailLabel.innerText = "Email";
    productContent.appendChild(emailLabel);

    var productContent = createNode("DIV", [{"name":"id", "value":"Remove"}, {"name":"class", "value":"column sides table-header center-align"}]);
    content.appendChild(productContent);
    var remove = createNode("LABEL",[{"name":"id","value":"Remove"}]);
    remove.innerText = "Remove";
    productContent.appendChild(remove);

    var productContent = createNode("DIV", [{"name":"id", "value":"Edit"}, {"name":"class", "value":"column sides table-header center-align"}]);
    content.appendChild(productContent);
    var edit = createNode("LABEL",[{"name":"id","value":"Edit"}]);
    edit.innerText = "Edit";
    productContent.appendChild(edit);
    content.innerHTML += "<br/>";
}

// ========== < < EVENT HANDLING AND BASIC PAGE FUNCTIONS > > ========== \\

//Allows for creation of HTML elements                                                                                  //done - good
function createNode(element, attrs)
{
    var node = document.createElement(element);
    attrs.forEach(function (attr){
        node.setAttribute(attr.name, attr.value);
    });
    return node;
}

//Creates Listeners
function createEventListener()
{
    var logoutButton = document.getElementById("logout");
    var loginButton = document.getElementById("login");
    var newProductButton = document.getElementById("newProduct");
    var viewProductsButton = document.getElementById("myProducts");
    var searchProductsButton = document.getElementById("searchProducts");
    var newAdminButton = document.getElementById("newAdmin");
    var editAdminButton = document.getElementById("editAdmin");

    if (loginButton.addEventListener)
    {
        //Create Events for displaying the form
        loginButton.addEventListener("click",displayLogin,false);
    }
    else if (loginButton.attachEvent)
    {
        //Create Events for displaying the form
        loginButton.attachEvent("onclick",displayLogin);
    }

    if (logoutButton.addEventListener)
    {
        //Create Events for displaying the form
        logoutButton.addEventListener("click",logout,false);
    }
    else if (logoutButton.attachEvent)
    {
        //Create Events for displaying the form
        logoutButton.attachEvent("onclick",logout);
    }

    if (newProductButton.addEventListener)
    {
        //Create Events for displaying the form
        newProductButton.addEventListener("click",displayAddProductForm,false);
    }
    else if (newProductButton.attachEvent)
    {
        //Create Events for displaying the form
        newProductButton.attachEvent("onclick",displayAddProductForm);
    }

    if (viewProductsButton.addEventListener)
    {
        //Create Events for displaying the form
        viewProductsButton.addEventListener("click",showProducts,false);
    }
    else if (viewProductsButton.attachEvent)
    {
        //Create Events for displaying the form
        viewProductsButton.attachEvent("onclick",showProducts);
    }

    if (searchProductsButton.addEventListener)
    {
        //Create Events for displaying the form
        searchProductsButton.addEventListener("click",displaySearchProductForm,false);
    }
    else if (searchProductsButton.attachEvent)
    {
        //Create Events for displaying the form
        searchProductsButton.attachEvent("onclick",displaySearchProductForm);
    }

    if (newAdminButton.addEventListener)
    {
        //Create Events for displaying the form
        newAdminButton.addEventListener("click",displayAddAdminForm,false);
    }
    else if (newAdminButton.attachEvent)
    {
        //Create Events for displaying the form
        newAdminButton.attachEvent("onclick",displayAddAdminForm);
    }

    if (editAdminButton.addEventListener)
    {
        //Create Events for displaying the form
        editAdminButton.addEventListener("click",showAdmin,false);
    }
    else if (editAdminButton.attachEvent)
    {
        //Create Events for displaying the form
        editAdminButton.attachEvent("onclick",showAdmin);
    }
}

//Determine which "event listener" to run (HTML5 compliant or not)                                                      //done - good
if (window.addEventListener)
{
    window.addEventListener("load",createEventListener,false);
}
else if (window.attachEvent)
{
    window.attachEvent("onload", createEventListener);
}
