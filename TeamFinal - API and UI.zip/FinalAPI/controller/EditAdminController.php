<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 4/17/2018
 * Time: 7:58 PM
 */

class EditAdminController extends AbstractBaseController {
    function process($params){
        $body = file_get_contents("php://input");
        $JSON = json_decode($body, true);

        $adminID = $JSON["adminID"];
        $password = $JSON["password"];
        $name = $JSON["name"];
        $email = $JSON["email"];

        $DAO = new EditAdminDAO();
        $user = $DAO->update($adminID,$password,$name,$email);

        if($user == null){
            $this->data["statusCode"] = 500;
            $this->data["statusMsg"] = "No user found";
            return;
        }

        $this->data["statusCode"] = 200;
        $this->data["statusMsg"] = "Successful";


        $this->data["user"] = $user;

    }
}